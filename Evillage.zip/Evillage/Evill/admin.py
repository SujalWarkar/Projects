from django.contrib import admin
from Evill.models import * 
# Register your models here.
admin.site.register(donate_data)
admin.site.register(contact_data)